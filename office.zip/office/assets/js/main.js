// 短信系统等页面点击左侧顶部导航切换内容
function clickSwitch() {
	$(".nav-sms").find("a").click(function () {
		var $this = $(this);
		var i = $this.parent().index();
		var $sendSms = $this.parents(".nav-sms").next();
		var $childrens = $this.parents(".sms").next().children();
		var $children = $childrens.eq(i-1);
		$this.addClass("current");
		$this.parent().siblings().children().removeClass("current");
		switch(i) {
			case 0:
				$sendSms.removeClass("hide");
				$childrens.addClass("hide");
				break;
			case i:
				$sendSms.addClass("hide");
				$children.removeClass("hide");
				$children.siblings().addClass("hide");
				break;
		}
	})
}

// 点击label文本框获得焦点
function clickFocus() {
	$("label").not(".not").click(function () {
		$(this).next().focus();
	})
}

// 点击 星级前面的复选框及全选按钮 选中与否切换
function selectCheckbox() {
	$(".select").click(function () {
		var $this = $(this);
		var checkbox = $this.prev();
		var starRank = $this.nextAll();
		var bool = $this.hasClass("select-all");
		if(checkbox.prop("checked") === true) {
			checkbox.prop("checked", false);
			if(bool) {
				starRank.prop("checked", false);
			}
		} else {
			checkbox.prop("checked", true);
			if(bool) {
				starRank.prop("checked", true);
			}
		}
	})
}

// 点击 顶部的全选复选框按钮 全部复选框选中与否切换
function selectAll() {
	$(".checkbox-all").click(function () {
		var $this = $(this);
		var checkbox = $this.parents("thead, .search-box").next().find(":checkbox");
		if($this.prop("checked")) {
			checkbox.prop("checked", true);
		} else {
			checkbox.prop("checked", false);
		}
	})
}
//客户详情  基本资料 站内信 弹窗
function checkAll() {
    $(".checks-all").click(function () {
        var $this = $(this);
        var checkbox = $this.parents(".list-a, .n-flex").find(":checkbox");
        if($this.prop("checked")) {
            checkbox.prop("checked", true);
        } else {
            checkbox.prop("checked", false);
        }
    })
}

//客户详情  基本资料 呼叫 弹窗
function changeInp() {
    $('.change-btn').click(function (){
        var $this = $(this);
        var $form = $this.parents('form');

        if($form.hasClass('editA')){
            $this.text('完成');
            $form.removeClass('editA');
            $this.prev('input').removeAttr('disabled');
        }else {
            $this.text('更改');
            $form.addClass('editA');
            $this.prev('input').attr('disabled','disabled');
        }
    })
}

function slidingCheck(){
    var $btnCheck = $(".check-c");

    $btnCheck.change(function(){
        var $this =$(this);
        var $test = $this.parents('label').find('em').text();
        if($this.is(':checked')){
            layer.msg($test + '为开启', {
                time:2000
            });
            /*layer.open({
                type: 1,
                move: false,
                skin: 'pop-up btnOne',
                closeBtn: 1,
                maxmin: false,
                shade: [0.7, "black"],
                area: ['300px', '160px'],
                content: '<div id="layer-account">' + $test +'为开启'+ '</div>',
                btn: ["确 定"]
            })*/
        }else{
            layer.msg($test + '为关闭');
            /*layer.open({
                type: 1,
                move: false,
                skin: 'pop-up btnOne',
                closeBtn: 1,
                maxmin: false,
                shade: [0.7, "black"],
                area: ['300px', '160px'],
                content: '<div id="layer-account">' + $test +'为关闭'+ '</div>',
                btn: ["确 定"]
            })*/
        }
    })
}

//银银资料 设置默认卡
var setDefault = function (){
    var $setBtn = $(".set-d-btn");

    $setBtn.change (function(){
        var $this = $(this);
        if($this.is(':checked')){
            layer.msg('设置成功！', {
                time:2000
            });
        } else {
            layer.msg('取消设置！', {
                time:2000
            });
        }
    })
}

var initEditor = function (id) {
    var E = window.wangEditor;
    $('#cont_sub_' + id).find('.editor2').attr('id', "editor2_" + id);
    if($("#editor2_" + id).find('.w-e-toolbar').length === 0) {
        (new E("#editor2_" + id)).create();
    }

    $('#cont_sub_' + id).find('a[href="#viewed"]').attr({
        'href': '#viewed_' + id,
        'aria-controls': 'viewed_' + id
    });
    $('#cont_sub_' + id).find('a[href="#nview"]').attr({
        'href': '#nview_' + id,
        'aria-controls': 'nview_' + id
    });
    $('#cont_sub_' + id).find('#viewed').attr('id', "viewed_" + id);
    $('#cont_sub_' + id).find('#nview').attr('id', "nview_" + id);
};

$(document).ready(function () {

	// 顶部走马灯滚动效果
	$('.marquee').marquee({
		//speed in milliseconds of the marquee
		duration: 20000,
		//gap in pixels between the tickers
		gap: 0,
		//time in milliseconds before the marquee will start animating
		delayBeforeStart: 0,
		//'left' or 'right'
		direction: 'left',
		//true or false - should the marquee be duplicated to show an effect of continues flow
		duplicated: true,
		allowCss3Support: true,
		pauseOnHover: true
	});

    // 全局多选下拉框事件绑定
    $('body').on('click', '.mul-select-group input', function() {
        $(this).siblings('ul').toggle();
    });

    $('body').on('click', '.mul-select-group li', function() {
        var allBtn = $(this).parent().find('.all-btn');
        allBtn.removeClass('selected');

        $(this).toggleClass('selected');
        var $lis = $(this).parent().find('li.selected');
        var val = [];
        for (var i = 0; i < $lis.length; i++) {
          val.push($lis.eq(i).html());
        }
        $(this).parent().siblings('input').val(val.join(','));
    });

    $('body').on('click', '.all-btn', function() {
        var $aLi = $(this).parent().find('li');
        var val = [];
        for (var i = 0; i < $aLi.length; i++) {
            val.push($aLi.eq(i).html());
        }

        if ($aLi.hasClass('selected')){
            $(this).removeClass('selected');
            $aLi.removeClass('selected');
            $(this).parent().siblings('input').val('');
        } else {
            $(this).addClass('selected');
            $aLi.addClass('selected');
            $(this).parent().siblings('input').val(val.join(','));
        }
    });

	  // 站内信-客户关怀-关怀类型对应内容切换
		$('body').on('change', '#select', function () {
			var $this = $(this);
			var i = $this.get(0).selectedIndex;
			var forms = $this.parent().next().children();
			forms.addClass("hide");
			forms.eq(i).removeClass("hide");
		});

   // 动态添加全局“新增提案”按钮
   layer.open({
    type: 1,
    skin: 'layer-proposal',
    title: false,
    shade: false,
    btn: false,
    move: '.dragProposal',
    offset: 'lb',
    resize: false,
    content: '<div class="new-proposal"><span class="dragProposal">新增提案</span><i class="if icon-plus"></i><div>',
    success: function() {
      $('.new-proposal .icon-plus').click(function() {
        var index = layer.open({
          type: 1,
          move: false,
          skin: 'office',
          title: "新增提案",
          closeBtn: 1,
          maxmin: false,
          shade: [0.7, "black"],
          area: ['700px', '720px'],
          content: '<div id="layer-account">' + $('#account').html() + '</div>',
          btn: ["提 交", "取 消"],
          success: function () {
            var account = $("#layer-account");
            // 点击顶部导航切换内容
            account.children("ul.nav").find("a").click(function () {
              var $this = $(this);
              var i = $this.parent().index();
              var form = account.find("form").eq(i);
              form.removeClass("hide");
              form.siblings().addClass("hide");
              $this.addClass("current");
              $this.parent().siblings().children().removeClass("current");
            });

            // 点击复制按钮复制文本框内容
            account.find("span.copy").click(function () {
              var textarea = $(this).prev();
              if (textarea.val() !== '') {
                textarea.select();
                document.execCommand("copy");
              }
            });

	          // 点击 顶部的全选复选框按钮 全部复选框选中与否切换
	          selectAll();

            // 点击label文本框获得焦点
	          clickFocus();

	          // 点击查看会员详情关闭弹出层
	          $(".member-details").click(function () {
		          layer.close(index);
	          });

          }
        });
      });
    }
  });

	// 默认LOAD 首页 home.html
	$("#home").load('/home.html', function () {
		// 点击 交班和点击查看更多 跳到交班系统
		$(".exchange").click(function () {
			$("#tab_30").trigger("click");
		});

		// 点击顶部右上角产品名改变
		$("#setting").find("li").click(function () {
			var $this = $(this);
			var txt = $this.text();
			$this.parents("div.bottom").prev().children("span").text(txt);
		})

	});

	// navbar 导航栏点击事件
	$('.navbar li').on('click', function () {
		var $this = $(this);
		var $nav = $this.parents('.navbar');
		var id = $this.attr('id').split('_')[1];
		var txt = $this.find('span').html();
		var url = $this.attr('data-url');

		if ($('#tag_' + id).length === 0 && $('#cont_' + id).length === 0) {
			$nav.find('.active').attr('class', 'visited');
			$this.attr('class', 'active');

			$('.sidebar li').removeClass('active');
			$('.sidebar ul').append('<li id="tag_' + id + '" class="active"><i class="if icon-close"></i><span>' + txt + '</span></li>');

			var $div = $('<div id="cont_' + id + '" class="content"></div>');
			$div.load(url, function () {
				$("#iframe .content").hide();
				$("#iframe").append($div);

				// 点击label文本框获得焦点
				clickFocus();

				// 点击 星级前面的复选框及全选按钮 选中与否切换
				selectCheckbox();

				// 点击 顶部的全选复选框按钮 全部复选框选中与否切换
				selectAll();

				// 短信系统等页面点击左侧顶部导航切换内容
				clickSwitch();

				// 点击 草稿箱-消息编号 跳到第一个（发送短信或发送站内信）
				$(".smsNo").click(function () {
					$(this).parents(".system-cont").prev().find("a").eq(0).trigger("click");
				});

				// 大厅管理-游戏厅开关-操作
				$(".operate").click(function () {
					layer.open({
						type: 1,
						move: false,
						skin: 'office hall',
						title: "游戏厅开关操作",
						closeBtn: 1,
						maxmin: false,
						shade: [0.7, "black"],
						area: ['600px', '400px'],
						content: $('#operate').html(),
						btn: ["提 交", "取 消"],
						success: function () {
							// 点击 星级前面的复选框及全选按钮 选中与否切换
							selectCheckbox();
						}
					});
				});

			});
		} else {
			$nav.find('.active').attr('class', 'visited');
			$this.attr('class', 'active');
			$('#tag_' + id).addClass('active').siblings('li').removeClass('active');
			$('#cont_' + id).fadeIn().siblings('.content').hide();
		}
	});

    // 导航栏大头针pin点击事件
    $('.navbar .pin').on('click', function() {
    $(this).parent('.navbar').toggleClass('open');
  });

	// 侧边栏标签点击事件
	$('.sidebar ul').on('click', 'li', function () {
		var id = $(this).attr('id');
		id = id ? id.split('_')[1] : '';

		if (id === '') {
			// 首页
			$(this).addClass('active').siblings().removeClass('active');
			$('.navbar .active').attr('class', 'visited');
			$('#home').fadeIn().siblings().hide();
		} else {
			$("#tab_" + id).trigger('click');
		}
	});

	// 侧边栏 删除标签
	$('.sidebar ul').on('click', '.icon-close', function (e) {
		e.stopPropagation();
		var $tag = $(this).parent();
		var id = $tag.attr('id').split('_')[1];
		var $prev = $tag.prev();
		$tag.remove();
		$('#tab_' + id).removeAttr('class');
		$('#cont_' + id).remove();
		$prev.trigger('click');
	});

	//客户名单 搜索折叠展开
	$("#iframe").on("click", ".search-box .arrow-btn", function(){
    var $this= $(this);
    var $srBox = $(this).parents('.form-inline').find('.search-child');

		if($this.hasClass('icon-arrow-down')) {
      $this.addClass('icon-arrow-up').removeClass('icon-arrow-down');
      $srBox.addClass('search-show');
		} else {
      $this.addClass('icon-arrow-down').removeClass('icon-arrow-up');
      $srBox.removeClass('search-show');
		}
	});

    // 涉及到子页面添加内容的公共调用方法
    $("body").on('click', '*[data-sub-url]', function() {
    var $this = $(this);
    var $iframe = $("#iframe");
    var url = $this.attr('data-sub-url');
    var $sCon = $('<div class="content"></div>');
    var id = $this.attr('id');

    if(id !== undefined) {
      $('#iframe > .content').hide();
      $('#cont_sub_' + id.split('_')[2]).show();

    } else {
      var tmpTime = (new Date()).getTime();
      $this.attr('id', 'tag_sub_' + tmpTime);
      $sCon.attr('id', 'cont_sub_' + tmpTime);

      $sCon.load(url, function() {
        $iframe.find('.content').hide();
        $iframe.append($sCon);

	      // 系统消息页面点击左侧顶部导航切换内容
	      clickSwitch();

		  // 系统消息页面点击 顶部的全选复选框按钮 全部复选框选中与否切换
	      selectAll();

	      // 系统消息页面点击label文本框获得焦点
	      clickFocus();

          //编辑器初始化
          initEditor(tmpTime);

          //银行资料 设置默认
          setDefault();

      });
    }

  });

    $('body').on('focus', '.datetime', function() {
     laydate.render({
      elem: this,
      type: 'datetime',
      show: true
    });
  });

    // 站内信或短信系统详情页面点击右侧导航切换内容
    $("#iframe").on('click', '.details-nav a', function() {
      var $this = $(this);
      var i = $this.parent().index();
      var block = $this.parents(".details-nav").next().children().eq(i);
      block.removeClass("hide");
      block.siblings().addClass("hide");
      $this.addClass("current");
      $this.parent().siblings().children().removeClass("current");

			// 点击 顶部的全选复选框按钮 全部复选框选中与否切换
	    selectAll();

		  // 点击label文本框获得焦点
	    clickFocus();

  });

    //取款提案 -审核结果 - 表格（操作 查看提案数据 - 系统审核结果 点tr下拉table）
    $("#iframe").on("click", "#tab-item tbody tr:nth-child(odd)", function(){
        var $this = $(this);
        // $(this).parent('.navbar').toggleClass('open');
        $this.next('tr').toggleClass('tab-show');



        /*if($this.next('tr').hasClass('table-m')){
            $this.next('.table-m').show();
		}*/
    });

    //注单查询 查询 统计按钮点击折叠隐藏
    $("#iframe").on("click", ".stats-btn", function(){
    	var $parent = $(this).parents('.search-box');
        $parent.siblings('.tab-wrap').eq(0).removeClass('hide');
        $parent.siblings('.tab-wrap').eq(1).addClass('hide');
		});
    $("#iframe").on("click", ".se-btn", function(){
        var $parent = $(this).parents('.search-box');
        $parent.siblings('.tab-wrap').eq(1).removeClass('hide');
        $parent.siblings('.tab-wrap').eq(0).addClass('hide');
    });

    //查询  客户名单(真钱开户、试玩开户、更改状态) 弹窗
    $("#iframe").on("click", ".money-open", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'office',
            title: "客户名单-真钱开户",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['700px', '600px'],
            content: '<div id="layer-account-a">' + $('#money-open').html() + '</div>',
            btn: ["提 交", "取 消"],
            success: function() {
                $("#layer-account-a .sel-list").change(function() {
                    var $this = $(this);
                    var oldInp = $this.parents('.layer-cont').find('.old-input');
                    if($this.val() === '新旧账号转移') {
                        oldInp.removeClass('hide');
                    } else {
                        oldInp.addClass('hide');
                    }
                });
            }
        });
    });

    $("#iframe").on("click", ".try-open", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up btnOne',
            title: "客户名单-试玩开户",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['400px', '350px'],
            content: '<div id="layer-account">' + $('#try-open').html() + '</div>',
            btn: ["关 闭"]
        });
    });

    $("#iframe").on("click", ".change-state", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up',
            title: "客户名单-更改状态",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['500px', '420px'],
            content: '<div id="layer-account">' + $('#change-state').html() + '</div>',
            btn: ["保 存", "取 消"],
            success: function () {
                slidingCheck();
            }
        });
    });

    //审批提案-存款提案  审批 弹窗
    $("#iframe").on("click", ".vetting-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up',
            title: "审批提案",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['460px', '300px'],
            content: '<div id="layer-account">' + $('#vettingPop').html() + '</div>',
            btn: ["提 交", "关 闭"],
            success: function () {
                var $btnChecking = $(".layui-layer-btn0");

                $btnChecking.on("click", function(){
                    layer.open({
                        type: 1,
                        move: false,
                        skin: 'pop-up',
                        title: "提示",
                        closeBtn: 1,
                        maxmin: false,
                        shade: [0.7, "black"],
                        area: ['460px', '150px'],
                        content: '<div id="layer-account">' + $('#vettingSuccPop').html() + '</div>',
                        btn: ["查看提案明细", "关 闭"]
                    })
                })
            }
        });
    });

    //审批提案-优惠提案  自动检查 弹窗
    $("#iframe").on("click", ".auto-check", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up',
            title: "自动检查",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['460px', '200px'],
            content: '<div id="layer-account">' + $('#autoCheck').html() + '</div>',
            btn: ["开始检查", "关 闭"],
            success: function () {
                var $btnChecking = $(".layui-layer-btn0");

                $btnChecking.on("click", function(){
                    layer.open({
                        type: 1,
                        move: false,
                        skin: 'pop-up',
                        closeBtn: 1,
                        maxmin: false,
                        shade: [0.7, "black"],
                        area: ['780px', 'auto'],
                        content: '<div id="layer-account">' + $('#startCheck').html() + '</div>',
                        btn: ["拒 绝", "关 闭"],
                        success: function(){
                            selectAll();
                        }
                    });


                })
            }
        });
    });

    //交易记录-交易单号 取款提案-审核结果  提案号 弹窗
    $("#iframe").on("click", ".bill-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up btnOne',
            title: "取款详情",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['1200px', '750px'],
            content: '<div id="layer-account">' + $('#withdrawal-detail').html() + '</div>',
            btn: ["关 闭"]
        });
    });

    //优惠提案-提案号 弹窗
    $("#iframe").on("click", ".promo-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up btnOne',
            title: "优惠详情",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['1200px', '750px'],
            content: '<div id="layer-account">' + $('#promo-detail').html() + '</div>',
            btn: ["关 闭"]
        });
    });

    //信息修改-提案号（修改类型为银行资料） 弹窗
    $("#iframe").on("click", ".info-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up btnOne',
            title: "银行资料详情",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['1200px', '750px'],
            content: '<div id="layer-account">' + $('#bank-detail').html() + '</div>',
            btn: ["关 闭"]
        });
    });

    //信息修改-提案号（修改类型为电话） 弹窗
    $("#iframe").on("click", ".phone-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up btnOne',
            title: "银行资料详情",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['1200px', '750px'],
            content: '<div id="layer-account">' + $('#phone-detail').html() + '</div>',
            btn: ["关 闭"]
        });
    });

    //信息修改-提案号（修改类型为姓名） 弹窗
    $("#iframe").on("click", ".name-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up btnOne',
            title: "姓名资料详情",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['1200px', '750px'],
            content: '<div id="layer-account">' + $('#name-detail').html() + '</div>',
            btn: ["关 闭"]
        });
    });

    //客户详情 增加提款账户
    $("#iframe").on('click', '.csr-details .addBank-btn', function() {
        var $this = $(this);
        var $contBox = $this.parents('.right-box').find('.cont');
        var $bCard = $contBox.find('.bank-card');

        $contBox.append($bCard.eq(0).clone());
    });

    //客户详情 删除提款账户
    $("#iframe").on('click', '.csr-details .btn-del', function() {
        var $this = $(this);

        layer.confirm('确认要删除吗？', {
            btn: ['确定','修改']
        }, function(){
            layer.msg('删除成功');
            setTimeout(function(){
                $this.parents('.bank-card').remove();
            }, 3000);
        });
    });

    //客户详情 银行资料 设置默认
    /*$("#iframe").on('click', '.csr-details .btn-del', function() {
        var $this = $(this);



    });*/

    //交班记录详情 编辑
    $("#iframe").on('click', '.s-logs .edit-btn', function() {
        var $this = $(this);
        var $listInput = $this.parents('.tit-edit').next('.list-user');
        var $section = $this.parents('.section');
        var id = 'editor_' + $this.parents('.content').attr('id').split('_')[2];

        $listInput.toggleClass('editA');
        if($listInput.hasClass('editA')){
            $this.text('编辑');
            $listInput.find('dl dd input, dl dd select').attr('disabled', 'disabled');

            $section.find('.editor-box .w-e-text').attr('contenteditable', false);
        } else {
            $this.text('完成');
            $listInput.find('dl dd input, dl dd select').removeAttr('disabled');

            if($section.find('.w-e-toolbar').length){
                $section.find('.editor-box .w-e-text').attr('contenteditable', true);
            } else {
                $section.find('.editor').attr('id', id);
                var E = window.wangEditor;
                var editor = new E('#' + id);
                editor.customConfig.uploadImgShowBase64 = true;
                editor.create();
            }
        }
    });

    //交班记录查看 下拉
    $("#iframe").on('click', '.s-logs .sel-cont', function() {
        var $lTop = $(this).parents('.l-top');

        $lTop.toggleClass('l-toggle');
    });

    //交班记录查看 下拉 关闭按钮
    $("#iframe").on('click', '.s-logs .close-btn', function() {
        var $lTopA = $(this).parents('.l-top');

        $lTopA.removeClass('l-toggle');
    });

    //客户名单 模糊
    $("#iframe").on('click', '.search-box .icon-vague', function() {
       var $this = $(this);
       var $input = $this.parents('.form-group').find('input');

       if($input.attr("type") === "text") {
           $input.prop("type", "password");
           $this.addClass("On");
       } else {
           $input.prop("type", "text");
           $this.removeClass("On");
       }
    });

    //客户详情  基本资料 设置
    $("#iframe").on("click", ".icon-setting", function(){
        var $this = $(this);
        var $lCard = $this.parents('.l-card');


        if($lCard.hasClass('editA')){
            $lCard.removeClass('editA');
            $lCard.find('input').removeAttr('disabled');
        }else {
            $lCard.addClass('editA');
            $lCard.find('input').attr('disabled','disabled');
        }



    });

    //客户详情 呼叫 弹窗
    $("#iframe").on("click", ".call-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'office',
            title: "拨打电话",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['650px', '380px'],
            content: '<div id="layer-account">' + $('#dial-number-pop').html() + '</div>',
            btn: ["提 交"],
            success: function () {
                changeInp();
            }
        });
    });

    //客户详情 站内信弹窗
    $("#iframe").on("click", ".letter-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'office',
            title: "发送站内信",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['700px', '570px'],
            content: '<div id="layer-account">' + $('#letter-standing').html() + '</div>',
            btn: ["发 送", "取 消"],
            success: function () {
                checkAll();
            }
        });
    });

    //客户详情 加关注弹窗
    $("#iframe").on("click", ".concern-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'office',
            title: "定制关注内容",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['650px', '570px'],
            content: '<div id="layer-account">' + $('#concern-pop').html() + '</div>',
            btn: ["保 存"],
            success: function () {
                checkAll();
            }
        });
    });

    //客户详情 短信弹窗
    $("#iframe").on("click", ".sends-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'office',
            title: "发送短信",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['650px', '380px'],
            content: '<div id="layer-account">' + $('#send-sms-pop').html() + '</div>',
            btn: ["取 消","发 送"]
        });
    });

    //客户详情 短信订阅 弹窗
    $("#iframe").on("click", ".sms-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up',
            title: "短信订阅",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['500px', '350px'],
            content: '<div id="layer-account">' + $('#sms-pop').html() + '</div>',
            btn: ["修 改","关 闭"]
        });
    });

    //客户详情 更改等级 弹窗
    $("#iframe").on("click", ".level-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'office',
            title: "更改等级",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['600px', '360px'],
            content: '<div id="layer-account">' + $('#level-pop').html() + '</div>',
            btn: ["修 改","关 闭"]
        });
    });

    //客户详情 更改状态 弹窗
    $("#iframe").on("click", ".state-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up',
            title: "客户名单-更改状态",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['500px', '420px'],
            content: '<div id="layer-account">' + $('#change-state').html() + '</div>',
            btn: ["保 存", "取 消"],
            success: function () {
                slidingCheck();
            }
        });
    });

    //客户详情 更改上级 弹窗
    $("#iframe").on("click", ".changes-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'office',
            title: "更改上级",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['600px', '380px'],
            content: '<div id="layer-account">' + $('#changes-pop').html() + '</div>',
            btn: ["提 交", "取 消"]
        });
    });

    //客户详情 修改资料 弹窗


    //客户详情 重置密码 弹窗


    //资料修改 等级修改 弹窗

    $("#iframe").on("click", ".edit-level-btn", function(){
        layer.open({
            type: 1,
            move: false,
            skin: 'pop-up btnOne level-pop',
            title: "更改上级",
            closeBtn: 1,
            maxmin: false,
            shade: [0.7, "black"],
            area: ['470px', '510px'],
            content: '<div id="layer-account">' + $('#level-edit-pop').html() + '</div>',
            btn: ["关 闭"]
        });
    });

});

